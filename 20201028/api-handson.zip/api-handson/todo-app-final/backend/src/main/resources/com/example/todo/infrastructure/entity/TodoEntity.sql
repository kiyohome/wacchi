FIND_BY_USERID =
select
  *
FROM
  todo
WHERE
  user_id = :userId
ORDER BY
  todo_id