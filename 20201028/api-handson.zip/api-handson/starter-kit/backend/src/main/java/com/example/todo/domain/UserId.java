package com.example.todo.domain;

public class UserId {

    private final String value;

    public UserId(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }
}
