package com.example;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class SampleTest {

    @Test
    void test() {
        Assertions.assertTrue(true);
    }
}
