# CORSの設定

フロントエンドアプリでCORSを使用するための設定をしましたが、同様に、バックエンドアプリでもCORSを使用するための設定をする必要があります。

Nablarchでは、CORSを使用するためのハンドラを提供しています。このハンドラを使用するため、`rest-component-configuration`ファイルに次のコンポーネント定義を追加します。

なお、**リファレンス実装でも同様の実装をしています**。

```xml
<!-- CORS設定 -->
<component name="cors" class="nablarch.fw.jaxrs.cors.BasicCors">
  <property name="allowOrigins">
    <component class="nablarch.core.repository.di.config.StringListComponentFactory">
      <property name="values" value="${cors.origins}"/>
    </component>
  </property>
</component>
...
<component name="webFrontController" class="nablarch.fw.web.servlet.WebFrontController">
  <property name="handlerQueue">
    <list>
...
      <component class="nablarch.fw.jaxrs.JaxRsResponseHandler">
        <property name="responseFinishers">
            <list>
              <!-- CORSレスポンス -->
              <component class="nablarch.fw.jaxrs.cors.CorsResponseFinisher">
                <property name="cors" ref="cors" />
              </component>
            </list>
          </property>
      </component>

      <!-- CORSハンドラ -->
      <component class="nablarch.fw.jaxrs.CorsPreflightRequestHandler">
        <property name="cors" ref="cors" />
      </component>
...
```

続いて、コンポーネント定義で使用する環境依存値を設定します。`common.config`に、以下の値を追加します。

```
cors.origins=http://localhost:3000
```

これで、バックエンドのCORS設定については完了です。
