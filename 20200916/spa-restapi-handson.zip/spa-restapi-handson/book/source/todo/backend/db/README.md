# DBのマイグレーション

バックエンドでは、マイグレーションツールである[Flyway](https://flywaydb.org/)を使用して、データベース上のテーブルやテストデータを登録するようにします。

Flywayを使用するための設定は済んだ状態になっているため、事前準備は必要ありません。（[Maven Plugin | Flyway](https://flywaydb.org/documentation/maven/#installation)）

Flywayの実行は、バックエンドアプリを起動したタイミングで行われるようにします。この実装については、**リファレンス実装を流用**します。

## アプリ起動時のFlyway制御

Flywayは使用できる状態であるため、アプリが起動したらFlywayが実行されるように実装します。

リファレンス実装でも同様の実装をしているため、リファレンス実装にある`com.example.system.nablarch.FlywayExecutor`クラスを、同じパッケージに持ってきます。

次に、`rest-component-configuration.xml`に、次のコンポーネント定義を追加します。

```xml
<component name="dbMigration" class="com.example.system.nablarch.FlywayExecutor">
    <property name="dataSource" ref="dataSource"/>
    <property name="locations" value="${flyway.locations}" />
    <property name="cleanBeforeMigrate" value="${flyway.cleanBeforeMigrate}"/>
</component>
```

続けて、このコンポーネントがアプリ起動時に実行されるようにするため、`initializer`という名前のコンポーネント定義を次のように修正します。（参考：[Nablarch - オブジェクトの初期化処理を行う](https://nablarch.github.io/docs/LATEST/doc/application_framework/application_framework/libraries/repository.html#repository-initialize-object)）

```xml
<component name="initializer" class="nablarch.core.repository.initialization.BasicApplicationInitializer">
    <property name="initializeList">
        <list>
            <component-ref name="packageMapping" />
            <component-ref name="dbMigration" />
        </list>
    </property>
</component>
```

次に、コンポーネントで使用している環境依存値を、`common.config`に追加します。

```
# flywayの設定
flyway.locations=db/migration,filesystem:src/test/resources/db/testdata
flyway.cleanBeforeMigrate=true
```

{% hint style='danger' %}
ここでは、`cleanBeforeMigrate`が`true`になるように設定していますが、これを設定すると、アプリ起動時に毎回テーブルが初期化されることになります。ここではテストを簡単に繰り返し実行できるようにするためにこのような設定としますが、テスト用途以外で指定しないように注意してください。
{% endhint %}

これで、アプリ起動時にFlywayが実行され、`flyway.locations`設定値に配置しているSQLファイルによってマイグレーションが実行されるようになりました。

## DBコンテナの起動

PostgreSQLのDockerコンテナを起動していない場合は、バックエンドアプリを起動する前に起動します。既に起動している場合は、この手順はスキップしてください。

PostgreSQLをDockerコンテナで起動するため、`backend`ディレクトリで次のコマンドを実行します。

```
$ docker-compose -f docker/docker-compose.dev.yml up -d
```

次のコマンドを実行し、コンテナが起動していることを確認します。

```
$ docker-compose -f docker/docker-compose.dev.yml ps
      Name                     Command              State           Ports
----------------------------------------------------------------------------------
docker_postgres_1   docker-entrypoint.sh postgres   Up      0.0.0.0:5432->5432/tcp
```

## バックエンドアプリの起動確認

SQLファイルは、プロジェクト作成時に用意しているため、アプリを起動してFlywayが実行できることを確認することができます。`backend`ディレクトリで、次のコマンドを実行します。

```
mvn jetty:run
```


{% hint style='danger' %}
フロントエンド開発時に使用するモックサーバは、ここでバックエンドアプリと同じ`9080`ポートを使用しています。そのため、モックサーバが起動している状態でアプリを起動すると、`Error starting jetty: Failed to bind to 0.0.0.0/0.0.0.0:9080: Address already in use`といったようにアドレスが使用済みである旨のエラーが発生します。もし発生した場合は、モックサーバを停止してから、再度アプリを起動してください。
{% endhint %}


特にエラーが発生せず、起動が成功することを確認します。確認できたら、`Ctrl`+`C`でアプリを終了しておきます。
