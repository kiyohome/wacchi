# コンポーネント定義の設定

Nablarchでは、DIコンテナの機能を持つシステムリポジトリを提供しています。（参考：[Nablarch - システムリポジトリ](https://nablarch.github.io/docs/LATEST/doc/application_framework/application_framework/libraries/repository.html)）

DIコンテナで管理するコンポーネントは、通常はXMLファイルを使用して定義します。その他に、クラスに`SystemRepositoryComponent`アノテーションを付与する方法もあり、このアプリではこちらの方法を使用します。（[アノテーションを付与したクラスのオブジェクトを構築する | Nablarch](https://nablarch.github.io/docs/5u18-SNAPSHOT/doc/application_framework/application_framework/libraries/repository.html#repository-inject-annotation-component)）

なお、**リファレンス実装でも同様の実装しています**。

## パッケージ特定クラスの作成

Nablarchのガイドに従い、まず収集対象のパッケージを特定するためのクラスを作成します。`com.example.system.nablarch.di`パッケージに`ExampleComponentDefinitionLoader`クラスを作成し、次のように実装します。

```java
package com.example.system.nablarch.di;

import nablarch.core.repository.di.config.externalize.AnnotationComponentDefinitionLoader;

public class ExampleComponentDefinitionLoader extends AnnotationComponentDefinitionLoader {

    @Override
    protected String getBasePackage() {
        return "com.example";
    }
}
```

## サービスプロバイダの設定

続いて、作成したクラスをサービスプロバイダとして設定します。

`src/main/resoruces`の直下に`META-INF/services`ディレクトリを作成し、そのディレクトリに`nablarch.core.repository.di.config.externalize.ExternalizedComponentDefinitionLoader`という名前のテキストファイルを作成します。

作成したファイルの中に、先ほど作成したクラスを完全修飾名で記述します。

```
com.example.system.nablarch.di.ExampleComponentDefinitionLoader
```

これで、先ほど作成したクラスがサービスプロバイダとしてロードされるようになります。

## アクションクラスをシステムリポジトリから取得する設定

Nablarchのデフォルト設定では、アクションクラスのインスタンスはリクエスト毎に生成されますが、システムリポジトリのDIを利用したいため、インスタンスはシステムリポジトリから取得するように設定します。

コンポーネント定義ファイルである`rest-component-configuration.xml`を開き、`packageMapping`コンポーネントの定義に、`delegateFactory`プロパティの設定を追加します。

`src/main/resources/rest-component-configuration.xml`
```xml
  <!--パッケージマッピングの設定 -->
  <component name="packageMapping" class="nablarch.integration.router.PathOptionsProviderRoutesMapping">
    <property name="pathOptionsProvider">
...
    </property>
    <property name="delegateFactory">
      <component class="nablarch.fw.handler.SystemRepositoryDelegateFactory"/>
    </property>
  </component>
```

これで、アクションクラスのインスタンスをシステムリポジトリから取得するようになります。
