# ルーティング定義の設定

Nablarchでは、ルーティングアダプタという機能で、リクエストをどのアクションクラスで処理するかを定義することができます。（参考：[Nablarch - ルーティングアダプタ](https://nablarch.github.io/docs/LATEST/doc/application_framework/adaptors/router_adaptor.html)）

デフォルトの設定では、ルート定義ファイルと呼ばれるXMLファイルに、パスとアクションクラスのルーティングを定義していきます。しかし、バックエンドアプリでは、JAX-RSのアノテーション（`@PATH`や`@GET`等）を使用してルーティングを定義できるようにするため、設定を変更していきます。（参考：[ウィキペディア - JAX-RS](https://ja.wikipedia.org/wiki/JAX-RS)）

Nablarchでは、JAX-RSのアノテーションでルーティングを実現するためのディスパッチハンドラ`nablarch.integration.router.PathOptionsProviderRoutesMapping`が提供されているため、これを使用するようにコンポーネント定義を変更していきます。

この実装については、**リファレンス実装を流用**します。

ディスパッチハンドラは`packageMapping`という名前でコンポーネント定義されているため、リファレンス実装のコンポーネント定義ファイルである`src/main/resources/rest-component-configuration.xml`を確認します。

該当のコンポーネントが、次のように定義されています。

```xml
  <!--パッケージマッピングの設定 -->
  <component name="packageMapping" class="nablarch.integration.router.PathOptionsProviderRoutesMapping">
    <property name="pathOptionsProvider">
      <component class="nablarch.integration.router.jaxrs.JaxRsPathOptionsProvider">
        <property name="applicationPath" value="${nablarch.webApi.applicationPath}" />
        <property name="basePackage" value="${nablarch.commonProperty.basePackage}" />
      </component>
    </property>
    <property name="methodBinderFactory">
      <component class="nablarch.fw.jaxrs.JaxRsMethodBinderFactory">
        <property name="handlerList">
          <component class="com.example.system.nablarch.jaxrs.BodyConvertHandlerListFactory">
            <property name="preHandlers">
              <list>
                <component class="com.example.system.nablarch.handler.LoginCheckHandler"/>
              </list>
            </property>
          </component>
        </property>
      </component>
    </property>
    <property name="delegateFactory">
      <component class="nablarch.fw.handler.SystemRepositoryDelegateFactory"/>
    </property>
  </component>
```

この中の`methodBinderFactory`プロパティの設定は、現時点のバックエンドアプリでは不要であるため、それ以外の部分を流用します。

バックエンドアプリのコンポーネント定義ファイルである`src/main/resources/rest-component-configuration.xml`を開き、`packageMapping`という名前で定義されているコンポーネントを、`methodBinderFactory`プロパティの部分はそのままで、他の部分を、リファレンス実装と同じように定義します。

```xml
  <!--パッケージマッピングの設定 -->
  <component name="packageMapping" class="nablarch.integration.router.PathOptionsProviderRoutesMapping">
    <property name="pathOptionsProvider">
      <component class="nablarch.integration.router.jaxrs.JaxRsPathOptionsProvider">
        <property name="applicationPath" value="${nablarch.webApi.applicationPath}" />
        <property name="basePackage" value="${nablarch.commonProperty.basePackage}" />
      </component>
    </property>
    <property name="methodBinderFactory">
      <component class="nablarch.fw.jaxrs.JaxRsMethodBinderFactory">
        <property name="handlerList">
          <component class="nablarch.integration.jaxrs.jersey.JerseyJaxRsHandlerListFactory" />
        </property>
      </component>
    </property>
    <property name="delegateFactory">
      <component class="nablarch.fw.handler.SystemRepositoryDelegateFactory"/>
    </property>
  </component>
```

`pathOptionsProvider`プロパティの中で、環境依存値の`nablarch.webApi.applicationPath`と`nablarch.commonProperty.basePackage`が使用されているため、この値を設定します。（参考：[Nablarch - コンポーネント設定ファイルから環境依存値を参照する](https://nablarch.github.io/docs/LATEST/doc/application_framework/application_framework/libraries/repository.html#repository-user-environment-configuration)）

`basePackage`プロパティは、アクションクラスを探索する起点となるパッケージを指定します。このプロパティで使用している`nablarch.commonProperty.basePackage`環境依存値は、`common.config`ファイルに次のように定義されています。

`src/main/resources/common.config`
```
# プロジェクトのベースパッケージ
nablarch.commonProperty.basePackage=com.example
```

これはそのままで問題ないため、次のプロパティを確認します。

`applicationPath`プロパティは、パスで共通となる先頭部分を定義することができます。前述のとおり、このバックエンドアプリでは、REST APIのパスは`/api`から設定するようにします。そのため、JAX-RSのアノテーションでパス設定時に先頭の`/api`を毎回定義しなくていいように、`applicationPath`プロパティに`/api`を設定します。

`common.config`ファイルに、`nablarch.webApi.applicationPath`環境依存値を追加します。

`src/main/resources/common.config`
```
# REST APIのルートパス
nablarch.webApi.applicationPath=/api
```

`delegateFactory`プロパティには、アクションクラスのインスタンス生成方法をコントロールするためのコンポーネントを指定できます。リファレンス実装では、コンポーネント定義からアクションクラスを取得する`SystemRepositoryDelegateFactory`を設定していますので、これはそのまま同じように使います。

これで、JAX-RSアノテーションを使用したルーティングをアクションクラスで定義するための設定が完了です。
