# CORSの設定

ToDoアプリでは、フロントエンドとバックエンドを異なるアプリとして作成しています。それぞれのアプリを別々に配置および起動するため、ウェブコンテンツとしては異なるオリジンになります。（[オリジン | MDN](https://developer.mozilla.org/ja/docs/Glossary/Origin)）

セキュリティ上の理由から、ブラウザでは異なるオリジンへのリクエストを制限しています。（参考：[同一オリジンポリシー | MDN](https://developer.mozilla.org/ja/docs/Web/Security/Same-origin_policy)）

フロントエンドアプリからバックエンドアプリのREST APIにアクセスしようとすると、この制限によりエラーとなってしまいます。

この制限は、オリジン間リソース共有（以下CORS）と呼ばれる仕組みを利用して対応することができます。（参考：[オリジン間リソース共有 (CORS) | MDN](https://developer.mozilla.org/ja/docs/Web/HTTP/CORS)）

生成したクライアントコードでは、[Fetch API](https://developer.mozilla.org/ja/docs/Web/API/Fetch_API/Using_Fetch)を使用してHTTP通信を行います。リクエストを送信するための`fetch()`メソッドでは、引数の`init`オブジェクトに次の値を設定することで、CORSを使用することができます。（[リクエストにオプションを適用する | MDN](https://developer.mozilla.org/ja/docs/Web/API/Fetch_API/Using_Fetch#Supplying_request_options)）

```js
{
  mode: 'cors',
  credentials: 'include'
}
```

先ほど作成した`BackendService`でこの設定をするため、次のように実装します。リクエスト時に`mode`と`credentials`が設定されるように、`corsHandler`をMiddlewareとして実装します。実装した`corsHandler`を使用するために、`configuration`オブジェクトの`middleware`に追加します。

```js
const corsHandler: Middleware = {
  pre: async (context) => {
    return {
      url: context.url,
      init: {
        ...context.init,
        mode: 'cors',
        credentials: 'include'
      }
    };
  }
}

const configuration = new Configuration({
  middleware: [corsHandler, requestLogger]
});
```

これで、フロントエンドのCORS設定については完了です。
