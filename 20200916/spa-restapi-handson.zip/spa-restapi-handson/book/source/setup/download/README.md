# ハンズオン資料のダウンロード


## ハンズオンリポジトリのダウンロード

ハンズオンに関連する以下の資料が、[GitLabのリポジトリ](https://gitlab.com/tis-tiw/spa-restapi-handson/spa-restapi-handson)に格納されています。

- 本ドキュメント
- プロジェクトのひな形
- ToDoアプリのデザインモック
- ToDoアプリの実装サンプル（ハンズオン終了時点）

ハンズオンでは、プロジェクトのひな形とデザインモックを使用するため、リポジトリをダウンロードします。

`Git`をインストールしている場合は、以下のコマンドでリポジトリをクローンしてください。

```
$ git clone https://gitlab.com/tis-tiw/spa-restapi-handson/spa-restapi-handson.git
```

`Git`をインストールしていない、もしくは使わない場合は、以下のリンクからzipファイルをダウンロードし、任意の場所に解凍してください。

[GitLabからzipファイルをダウンロード](https://gitlab.com/tis-tiw/spa-restapi-handson/spa-restapi-handson/-/archive/master/spa-restapi-handson-master.zip)


## サービス開発サンプルリポジトリのダウンロード

サービス開発施策として提供されている実装サンプルが、[GitLabのリポジトリ](https://gitlab.com/tis-tiw/beta/chat-example)に格納されています。

ハンズオンでは、実装サンプルに含まれるいくつかの実装コードを流用するため、リポジトリをダウンロードします。

`Git`をインストールしている場合は、以下のコマンドでリポジトリをクローンしてください。

```
$ git clone https://gitlab.com/tis-tiw/beta/chat-example.git
```

`Git`をインストールしていない、もしくは使わない場合は、以下のリンクからzipファイルをダウンロードし、任意の場所に解凍してください。

[GitLabからzipファイルをダウンロード](https://gitlab.com/tis-tiw/beta/chat-example/-/archive/master/chat-example-master.zip)