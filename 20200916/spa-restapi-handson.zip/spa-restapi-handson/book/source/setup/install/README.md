# 開発環境の準備

ToDoアプリの開発で使用するツールをインストールします。

## Node.jsのインストール

フロントエンドの開発ではCreate React AppやTypeScriptを使用するため、Node.jsをインストールします。Node.jsのバージョンには、LTSである 12 を使用します。

[公式サイト](https://nodejs.org/ja/)の案内に沿って、インストールしてください。

使用する環境が既に整っている場合は、この手順をスキップしてください。

## JDKのインストール

バックエンドの開発ではJavaを使用するため、JDKをインストールします。Javaのバージョンには11を使用します。

JDKはいくつかありますが、ここでは、OpenJDKの1つであるAdoptOpenJDKをインストールします。
[公式サイト](https://adoptopenjdk.net/)の案内に沿って、インストールしてください。

使用する環境が既に整っている場合は、この手順をスキップしてください。

## Mavenのインストール

バックエンドの開発では構成管理にMavenを利用するため、Mavenをインストールします。バージョンは制限していませんが、現時点で最新である3.6.3でよいです。

[公式サイト](https://maven.apache.org/download.cgi)の案内に沿って、ダウンロードおよび配置してください。

使用する環境が既に整っている場合は、この手順をスキップしてください。

## Visual Studio Codeのインストール

開発時に使用するエディタをインストールします。

エディタは使い慣れたものなら何でもよいですが、何もインストールしていなければ、今回のハンズオンで使用するコードに対応できるVisual Studio Codeをインストールします。[公式サイト](https://azure.microsoft.com/ja-jp/products/visual-studio-code/)の案内に沿って、インストールしてください。

エディタが既に整っている場合は、この手順をスキップしてください。

## Docker(Docker Compose)のインストール

開発時にコンテナを使用するため、DockerとDocker Composeをインストールします。

WindowsでのDocker利用方法はいくつかありますがは、ここではDocker Desktop for Windowsをインストールします。[公式サイト](https://docs.docker.com/docker-for-windows/install/)の案内に沿って、インストールしてください。

使用する環境が既に整っている場合は、この手順をスキップしてください。

{% hint style='danger' %}
本ハンズオンでは、Dockerコンテナ起動時にローカルディレクトリをマウントします。Docker Desktop for Windowsでローカルディレクトリをマウントするためには、事前にファイル共有ができるように設定しておく必要があります。Docker Desktop for Windowsの`Settings`→`Resources`→`FILE SHARING`から、本ハンズオンでプロジェクトを作成するドライブ（通常はCドライブ）を共有可能としてチェックしておいてください。（参考：[User manual | Docker Desktop](https://docs.docker.com/docker-for-windows/)）
{% endhint %}

## Gitのインストール（オプション）

ハンズオン資料のダウンロードでGitを利用することもできるため、Gitをインストールします。ただし、他の手段でもダウンロードが出来るため、インストールは必須ではなく任意となります。

ここでは、Windows用にGitを使うための git fow windows をインストールします。[公式サイト](https://gitforwindows.org/)の案内に沿って、インストールしてください。