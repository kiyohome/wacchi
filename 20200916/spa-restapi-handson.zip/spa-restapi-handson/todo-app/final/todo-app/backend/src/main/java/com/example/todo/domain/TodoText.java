package com.example.todo.domain;

public class TodoText {

    private final String value;

    public TodoText(String value) {
        this.value = value;
    }

    public String value() {
        return value;
    }
}
