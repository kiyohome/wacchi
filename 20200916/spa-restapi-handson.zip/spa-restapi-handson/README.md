# このリポジトリについて

サービス開発施策のひとつである **サービス開発ハンズオン** の資料を格納するためのリポジトリです。

ハンズオンの実施手順を記載したドキュメントは、`GitLab Pages`にて以下のURLにデプロイしています。

https://tis-tiw.gitlab.io/spa-restapi-handson/spa-restapi-handson 
