import React from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-elements';

const MainNav: React.FC = () => {
  return (
    <View>
      <Text>MainNav</Text>
    </View>
  );
};

export default { name: 'main', component: MainNav };
