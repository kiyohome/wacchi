import React from 'react';
import { View } from 'react-native';
import { Text } from 'react-native-elements';

const RootNav: React.FC = () => {
  return (
    <View>
      <Text>RootNav</Text>
    </View>
  );
};

export default RootNav;
